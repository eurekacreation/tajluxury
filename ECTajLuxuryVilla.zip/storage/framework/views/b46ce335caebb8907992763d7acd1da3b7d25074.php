<!DOCTYPE html>
<html>
<body>

<h1>My first PHP page</h1>

<?php 


$ur = "marrakech-airport-essaouira.html";
echo 'marrakech-airport-essaouira.html';
echo '<br/> ---0---- <br/>';
$addr = str_replace( ".html", "" ,$ur);
echo $addr;
echo '<br/> ---1---- <br/>';
$addr = str_replace( "marrakech-airport", "" ,$addr);
echo $addr;
echo '<br/> ---2---- <br/>';
$array = explode('-', $addr);
echo $array[count($array)-1];
echo '<br/> ---3---- <br/>';







// if(isset($_POST['from'],$_POST['to'],$_POST['start'],$_POST['people'],$_POST['return'],$_POST['url']) && is_numeric($_POST['from']) && is_numeric($_POST['to']) &&  ($_POST['return']==0 || $_POST['return']==1) && $_POST['url']=="search"){
// 	echo '<br/> --YES--- <br/>';

// }else{
// 	echo '<br/> --NO--- <br/>';

// 	$url = $_SERVER['REQUEST_URI'];
// 	$url = str_replace( "/", "" ,$url);
// 	$url = str_replace( ".html", "" ,$url);
// 	echo '<br/>'.$url;
// 	echo '<br/>';
// 	$array = explode('-', $url);
// 	$URLfrom = $array[0].' '.$array[1];
// 	$URLto = $array[count($array)-1];
	


// }
 ?>
 </body>
</html>